#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="AccessModifier.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.Utilities.Editor.CodeGeneration
{
    /// <summary>
    /// Not yet documented.
    /// </summary>
    public enum AccessModifier
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        Private = 0,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        Protected = 1,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        Public = 2,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        Internal = 3,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        ProtectedInternal = 4
    }
}
#endif