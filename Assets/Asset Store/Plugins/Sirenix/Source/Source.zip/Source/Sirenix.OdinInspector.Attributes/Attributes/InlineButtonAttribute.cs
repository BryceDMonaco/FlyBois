﻿//-----------------------------------------------------------------------
// <copyright file="InlineButtonAttribute.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector
{
	using System;

	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property, AllowMultiple = true, Inherited = true)]
	public sealed class InlineButtonAttribute : Attribute
	{
		public string MemberMethod { get; private set; }
		public string Label { get; private set; }

		public InlineButtonAttribute(string memberMethod, string label = null)
		{
			this.MemberMethod = memberMethod;
			this.Label = label;
		}
	}
}