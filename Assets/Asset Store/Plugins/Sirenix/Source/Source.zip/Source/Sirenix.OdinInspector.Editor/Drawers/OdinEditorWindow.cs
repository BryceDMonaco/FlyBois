#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="OdinEditorWindow.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor
{
    using UnityEditor;
    using UnityEngine;
    using Sirenix.Serialization;

    /// <summary>
    /// Not yet documented.
    /// </summary>
    [ShowOdinSerializedPropertiesInInspector]
    public abstract class OdinEditorWindow : EditorWindow, ISerializationCallbackReceiver
    {
        [SerializeField, HideInInspector, ExcludeDataFromInspector]
        private SerializationData serializationData;

        private PropertyTree propertyTree;

        /// <summary>
        /// Not yet documented.
        /// </summary>
        public PropertyTree PropertyTree
        {
            get
            {
                if (this.propertyTree == null)
                {
                    this.propertyTree = PropertyTree.Create(this);
                }

                return this.propertyTree;
            }
        }

        void ISerializationCallbackReceiver.OnAfterDeserialize()
        {
            UnitySerializationUtility.DeserializeUnityObject(this, ref this.serializationData);
            this.OnAfterDeserialize();
        }

        void ISerializationCallbackReceiver.OnBeforeSerialize()
        {
            UnitySerializationUtility.SerializeUnityObject(this, ref this.serializationData);
            this.OnBeforeSerialize();
        }

        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected virtual void OnGUI()
        {
            this.PropertyTree.Draw();
        }

        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected virtual void OnAfterDeserialize()
        {
        }

        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected virtual void OnBeforeSerialize()
        {
        }
    }
}
#endif