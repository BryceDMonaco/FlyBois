#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="TitleAttributeDrawer.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Draws properties marked with <see cref="TitleAttribute"/>.
    /// </summary>
    /// <seealso cref="TitleAttribute"/>
    [OdinDrawer]
    [DrawerPriority(1, 0, 0)]
    public sealed class TitleAttributeDrawer : OdinAttributeDrawer<TitleAttribute>
    {
        private class TitleContext
        {
            public string ErrorMessage;
            public StringMemberHelper TitleHelper;
            public StringMemberHelper SubtitleHelper;
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(InspectorProperty property, TitleAttribute attribute, GUIContent label)
        {
            var context = property.Context.Get<TitleContext>(this, "TitleContext", (TitleContext)null);

            if (context.Value == null)
            {
                context.Value = new TitleContext();
                context.Value.TitleHelper = new StringMemberHelper(property.ParentType, attribute.Title, ref context.Value.ErrorMessage);
                context.Value.SubtitleHelper = new StringMemberHelper(property.ParentType, attribute.Subtitle, ref context.Value.ErrorMessage);
            }

            // Don't draw added emtpy space for the first property.
            if (property != property.Tree.GetRootProperty(0))
            {
                EditorGUILayout.Space();
            }

            if (context.Value.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(context.Value.ErrorMessage);
            }
            else
            {
                GUIStyle titleStyle = null;
                GUIStyle subTitleStyle = null;

                switch (attribute.TitleAlignment)
                {
                    case TitleAlignments.Left:
                        titleStyle = attribute.Bold ? SirenixGUIStyles.BoldTitle : SirenixGUIStyles.Title;
                        subTitleStyle = SirenixGUIStyles.Subtitle;
                        break;
                    case TitleAlignments.Centered:
                        titleStyle = attribute.Bold ? SirenixGUIStyles.BoldTitleCentered : SirenixGUIStyles.TitleCentered;
                        subTitleStyle = SirenixGUIStyles.SubtitleCentered;
                        break;
                    case TitleAlignments.Right:
                        titleStyle = attribute.Bold ? SirenixGUIStyles.BoldTitleRight : SirenixGUIStyles.TitleRight;
                        subTitleStyle = SirenixGUIStyles.SubtitleRight;
                        break;
                    case TitleAlignments.Split:
                        titleStyle = attribute.Bold ? SirenixGUIStyles.BoldTitle : SirenixGUIStyles.Title;
                        subTitleStyle = SirenixGUIStyles.SubtitleRight;
                        break;
                }


                if (attribute.TitleAlignment == TitleAlignments.Split)
                {
                    var rect = GUILayoutUtility.GetRect(0, 18, titleStyle, GUILayoutOptions.ExpandWidth());

                    GUI.Label(rect, context.Value.TitleHelper.GetString(property), titleStyle);
                    rect.y += 3;
                    GUI.Label(rect, context.Value.SubtitleHelper.GetString(property), subTitleStyle);

                    if (attribute.HorizontalLine)
                    {
                        SirenixEditorGUI.HorizontalLineSeperator(new Color32(90, 90, 90, 255), 1);
                        GUILayout.Space(3f);
                    }
                }
                else
                {
                    GUILayout.Label(context.Value.TitleHelper.GetString(property), titleStyle);
                    if (attribute.Subtitle != null)
                    {
                        GUILayout.Label(context.Value.SubtitleHelper.GetString(property), subTitleStyle);
                    }

                    if (attribute.HorizontalLine)
                    {
                        SirenixEditorGUI.HorizontalLineSeperator(new Color32(90, 90, 90, 255), 1);
                        GUILayout.Space(3f);
                    }
                }
            }

            this.CallNextDrawer(property, label);
        }
    }
}
#endif