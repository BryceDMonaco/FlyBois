//-----------------------------------------------------------------------
// <copyright file="PrefabModificationType.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.Serialization
{
    /// <summary>
    /// Not yet documented.
    /// </summary>
    public enum PrefabModificationType
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        Value,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        ListLength,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        Dictionary
    }
}